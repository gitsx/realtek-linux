#!/bin/bash

echo "###### Executing ADB commands to get ROOT privilege ######"
adb root
#adb remount


echo ""
echo "##### Installing \"RtkWiFiTest_20150609A.apk\" on DUT ######"
echo "Sending to DUT ..."
if [ -f RtkWiFiTest_20150609A.apk ]; then
adb install -r RtkWiFiTest_20150609A.apk
else
echo "\"RtkWiFiTest_20150609A.apk\" is not found !!!"
exit 0
fi
